/***************************************************************************
 *
 * This file includes part of the OpenKinect Project. http://www.openkinect.org
 *
 * Copyright (c) 2010 individual OpenKinect contributors. See the CONTRIB file
 * for details.
 *
 * This code is licensed to you under the terms of the Apache License, version
 * 2.0, or, at your option, the terms of the GNU General Public License,
 * version 2.0. See the APACHE20 and GPL2 files for the text of the licenses,
 * or the following URLs:
 * http://www.apache.org/licenses/LICENSE-2.0
 * http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * If you redistribute this file in source form, modified or unmodified, you
 * may:
 *   1) Leave this header intact and distribute it under the same terms,
 *      accompanying it with the APACHE20 and GPL20 files, or
 *   2) Delete the Apache 2.0 clause and accompany it with the GPL2 file, or
 *   3) Delete the GPL v2 clause and accompany it with the APACHE20 file
 * In all cases you must keep the copyright notice intact and include a copy
 * of the CONTRIB file.
 *
 * Binary distributions must follow the binary distribution requirements of
 * either License.
 *
 *   Copyright (C) 2010 by DTU                                             *
 *   jca@elektro.dtu.dk                                                    *
 ***************************************************************************/

#ifndef UFUNC_AUKINECT_H
#define UFUNC_AUKINECT_H

#include <stdint.h>

#include <ugen4/uimg3dpoint.h>
#include <urob4/ufuncplugbase.h>
#include <ucam4/uimagelog.h>

//#define USE_KINECT
#ifdef USE_KINECT
#include <libusb.h>
#include <libfreenect.h>
#include <ucam4/uimagelog.h>
#endif
//PCL
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>


/**
 * This is a simple example plugin, that manipulates global variables, both of its own, and those of other modules.
@author Christian Andersen
*/
class UFuncKinect : public UFuncPlugBasePush
{ // NAMING convention recommend that the plugin function class
  // starts with UFunc (as in UFuncKinect) followed by
  // a descriptive extension for this specific plug-in
public:
  /**
  Constructor */
  UFuncKinect()
  { // command list and version text
    setCommand("kinect kinectPush", "kinect", "Plug-in to get data from XBox 360 RGB and 3D camera");
    init();
  }
  /**
  Destructor */
  ~UFuncKinect();
  /**
   * Called by server after this module is integrated into the server core structure,
   * i.e. all core services are in place, but no commands are serviced for this module yet.
   * Create any resources that this modules needs. */
  virtual void createResources();
  /**
   * Handle incomming commands flagged for this module
   * \param msg pointer to the message and the client issuing the command
   * \return true if the function is handled - otherwise the client will get a 'failed' reply */
  virtual bool handleCommand(UServerInMsg * msg, void * extra);
  virtual bool methodCall(const char * name, const char * paramOrder, char ** strings, const double * pars,
                      double * value, UDataBase ** returnStruct, int * returnStructCnt);
  /**
  Called from push implementor to get the push object.
  should call to 'gotNewData(object)' with the available event object.
  if no object is available (anymore), then call with a NULL pointer. */
  virtual void callGotNewDataWithObject();
  //
  /**
  Decode this replay line, that is assumed to be valid - has got a timestamp.
  \param line is a pointer to the line.
  \returns true if the line is valid and used (step is successfull).
  \returns false if line is not a valid step. */
  virtual bool decodeReplayLine(char * line);
  /**
  is called when it is time to update replay status (after a step in some replay file) */
  virtual void updateReplayStatus();


private:
  /**
  Initialize other variables */
  void init();
  /**
  produce fake disparity images - if requested.
  \param img is the true 16-bit depth image to process
  \returns true if successful - i.e. source images available*/
  bool processDepthImages(UImage * img);
  /**
  Handle stereo-push commands */
  bool handleKinect(UServerInMsg * msg);
  /// start read thread
  bool start();
  /** stop read thread
  \param andWait waits until thread is terminated, when false, then the call returns
  when the stop flag is set (i.e. immidiately). */
  void stop(bool andWait);

#ifdef USE_KINECT
  /**
  Open or close camera stream */
  bool openKinect(bool doOpen);

public:
  /**
  Callback function for depth image  */
  //void callback_depth(freenect_device *dev, freenect_depth *depth, uint32_t timestamp);
  void callback_depth(freenect_device *dev, uint16_t *depth, uint32_t timestamp);
  /**
  Callback function for color (RGB) image */
  void callback_rgb(freenect_device *dev, uint8_t *rgb, uint32_t timestamp);
#endif
public:
  /**
  Run receive thread */
  void run();
  // returns the 3D point cloud as a long list of variables
  int GetXYZCoordinates(void *pointCloud, int Max,int type);
  int MakePCLFile(UImage * img);
private:
  /**
   * Test for open or close logfiles using global variable */
  void logFileTest();
  /**
   * Save image to imagelog and save the image itself in the imagePath.
   * if camera device do not exist, then a default device is created..
   * \param imgToLog is the image to be logged. */
  bool logImageToFile(UImage * imgToLog);

private:

  static const int MWL = 100;
  /**
  Short explanation to why processing failed */
  char whyString[MWL];
  /**
  Pointers to "own" global variables. */
  UVariable * varUpdateCnt;
//  UVariable * varPoseOnRobot;
  UVariable * varTime;
  /**
  Stereo processing parameters */
  UVariable * varImagesC3D;
  UVariable * varCamDeviceNum;
//  UVariable * varDebug;
  UVariable * varIsOpen;
  UVariable * varFramerateDesired;
  UVariable * varFramerate;
  UVariable * varResolution;
/*  UVariable * varUseEveryCol;
  UVariable * varUseEveryDep;*/
  UVariable * varImgIR;
  UVariable * varTiltDeg;
  UVariable * varTiltUse;
  UVariable * varLed;
//  UVariable * varAccUse;
  UVariable * varAcc;
  UVariable * varAccRate;
  UVariable * varAccLogN;
  UVariable * varImageLogN;
  UVariable * varAccInterval;
  UVariable * varUseColor;
  UVariable * varUseDepth;
  UVariable * varUseCorrectedDepth;
  UVariable * varKinectNumber;
  UVariable * varUseDepth8bit;
  UVariable * varUseDepthColor;
  UVariable * varReplayLine;
  UVariable * varMakePCLFile;
  UVariable * varMaxUsedDepth;

  int oldLed;
  double oldTilt;
  /// is kinect initialized
  UVariable * varInitialized;
  /**
  General Logfile */
  ULLogFile logf;
  /**
  Logfile for acceleration measurement*/
  ULLogFile logAcc;
  /**
  Logfile */
  UImageLog logImage;
  /// pointer to depth image to log
  UImage * logDepthImage;
  /// pointer to video (color or IR) image to log
  UImage * logVideoImage;
  /**
  Array with 3d points */
  UImg3Dpoints cloud3d;

#ifdef USE_KINECT
  // kinect specific typed variables
  /**
  freenect handles */
  freenect_context *f_ctx;
  /// freenect device handle
  freenect_device *f_dev;
  /// libusb context handle
  freenect_usb_context * usbCtx;
  /// video format structure
  freenect_frame_mode depthFmt;
  /// video format structure
  freenect_frame_mode videoFmt;
#endif

  /// number of accepter depth frames
  int frameCntDepth;
  /// number of accepted video frames (rgb or ir)
  int frameCntRgb;
  /// frame count for logging
  int frameLogCnt;
  /// variable for frame rate calculation
  UTime frameRateDepthTime;
  /// variable for frame rate calculation
  UTime frameRateRgbTime;
  /**
  Gamma correction table from 11-bit depth - for better display */
  uint16_t t_gamma[2048];
  /**
  Depth correction table for kinect */
  uint16_t t_depth[2048];
  /**
  X-Position correction table for kinect */
  float t_posX[640];
  /**
  Y-Position correction table for kinect */
  float t_posY[480];

  /// thread runnung flag
  bool threadRunning;
  /// stop thread flag
  bool threadStop;
  /**
  Thread handle for frame read thread. */
  pthread_t threadHandle;
};


#endif

