/***************************************************************************
 *   Copyright (C) 2010 by DTU (Christian Andersen)                        *
 *   jca@elektro.dtu.dk                                                    *
 *
 * $Rev: 1730 $
 * $Id: ufunckinect.cpp 1730 2011-10-18 08:08:34Z jca $
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License as        *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 *
 *
 * This file includes part of the OpenKinect Project. http://www.openkinect.org
 *
 * Copyright (c) 2010 individual OpenKinect contributors. See the CONTRIB file
 * for details.
 *
 * This code is licensed to you under the terms of the Apache License, version
 * 2.0, or, at your option, the terms of the GNU General Public License,
 * version 2.0. See the APACHE20 and GPL2 files for the text of the licenses,
 * or the following URLs:
 * http://www.apache.org/licenses/LICENSE-2.0
 * http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * If you redistribute this file in source form, modified or unmodified, you
 * may:
 *   1) Leave this header intact and distribute it under the same terms,
 *      accompanying it with the APACHE20 and GPL20 files, or
 *   2) Delete the Apache 2.0 clause and accompany it with the GPL2 file, or
 *   3) Delete the GPL v2 clause and accompany it with the APACHE20 file
 * In all cases you must keep the copyright notice intact and include a copy
 * of the CONTRIB file.
 *
 * Binary distributions must follow the binary distribution requirements of
 * either License.
 ***************************************************************************/

/* edited by Kristian Villien 11/1-12
added variable for depth correction
added depth correction in new image pool
when using depth correction 8 bit image is using this pool
*/

#include <urob4/uvariable.h>
#include <urob4/uresposehist.h>
#include <urob4/uvarcalc.h>
#include <urob4/uimagepool.h>
#include <ucam4/ucammount.h>
#include <ucam4/ucampool.h>

#include "ufunckinect.h"

#include <pthread.h>

#ifdef LIBRARY_OPEN_NEEDED

///////////////////////////////////////////////////
// library interface
// used by server when function is loaded to create this object

UFunctionBase * createFunc()
{ // create an object of this type
  //
  /** replace 'UFuncKinect' with your classname, as used in the headerfile */
  return new UFuncKinect();
}

#endif


UFuncKinect * kinectObj = NULL;

//#define USE_KINECT
#ifdef USE_KINECT
/**
C-callback function for color image */
void rgb_cb(freenect_device *dev, void *rgb, uint32_t timestamp)
{
  if (kinectObj != NULL)
    kinectObj->callback_rgb(dev, (uint8_t *) rgb, timestamp);
}
/**
C-callback function for color image */
void depth_cb(freenect_device *dev, void /*freenect_depth */ * depth, uint32_t timestamp)
{
  if (kinectObj != NULL)
    kinectObj->callback_depth(dev, (uint16_t *)depth, timestamp);
}
#endif
///////////////////////////////////////////////////


UFuncKinect::~UFuncKinect()
{
  stop(true);
  if (varInitialized->getBool())
  { // close device
    openKinect(false);
    libusb_exit(usbCtx);
  }
  logImage.closeLogging();
  logAcc.closeLog();
  logf.closeLog();
}

/////////////////////////////////////////////////

void UFuncKinect::init()
{
  kinectObj = this;
  //initialize RGB depth gamma
  for (int i = 0; i < 2048; i++)
  {
    float v = i/2048.0;
    v = powf(v, 3)* 6;
    t_gamma[i] = v*6*256;
  }
  //initialize depth convertion
// values found at http://stackoverflow.com/questions/8663301/microsoft-kinect-sdk-depth-calibration
  float pixel;
  int i;
  for (i = 0; i < 1091; i++) //1090 is just above 10 meters, calculation screw up outside this range 
                             //valid kinect range is ~4m
  {
    pixel = (float) i;
    pixel = 123.6*tan(pixel/2842.5+1.1863); // depth in mm, note depth means Z position, not direct depth
    t_depth[i] = (uint16_t) round(pixel);
  }
  for (; i < 2048; i++) // when outside range, set to 0
    t_depth[i] = 0;//-1;

  //initialize position scaling
  const double fx_d = 595;
  const double fy_d = 595;
  const double cx_d = 640/2;
  const double cy_d = 480/2;
  for (int i = 0; i < 640; i++)
    t_posX[i] = (float)( (((double)i)-cx_d)/fx_d );
  for (int i = 0; i < 480; i++)
    t_posY[i] = (float)( (((double)i)-cy_d)/fy_d );

  threadRunning = false;
  threadStop = false;
  oldLed = -1;
  usbCtx = NULL;
  logDepthImage = NULL;
  logVideoImage = NULL;
  frameCntDepth = 0;
  frameCntRgb = 0;
}

///////////////////////////////////////////////////

bool UFuncKinect::handleCommand(UServerInMsg * msg, void * extra)
{ // message is unhandled
  bool result = false;
  //
  if (getCmdIndex() == 0)
    result = handleKinect(msg);
  else if (getCmdIndex() == 1)
    result = handlePush(msg);
  else
    sendDebug(msg, "Command not handled (by me)");
  return result;
}

///////////////////////////////////////////////////

bool UFuncKinect::handleKinect(UServerInMsg * msg)
{
  const int MRL = 500;
  char reply[MRL];
  char r[MRL];
  // check for parameter 'help'
  if (msg->tag.getAttValue("help", NULL, 0) or msg->tag.getAttCnt() == 0)
  { // create the reply in XML-like (html - like) format
    sendHelpStart(aliasName);
    snprintf(reply, MRL, "--- %s is a plugin to XBOX 360 3d camera\n", aliasName);
    sendText(reply);
    snprintf(reply, MRL, "open=true|false     Start or stop camera stream to img=%d (depth) and img=%d color\n",
             varImagesC3D->getInt(1), varImagesC3D->getInt(0));
    sendText(reply);
    sendText(            "silent              do not send a reply to this command\n");
    if (varImagesC3D != NULL)
    {
      snprintf(reply, MRL, "debug=true|false    Produce debug image (is %s for color-depth img=%d)\n",
               bool2str(varImagesC3D->getBool(0)), varImagesC3D->getInt(1));
      sendText(reply);
    }
    snprintf(reply, MRL, "log=true|false      action log (open=%s) to %s \n", bool2str(logf.isOpen()), logf.getLogFileName());
    sendText(reply);
    snprintf(reply, MRL, "logImage=N          logging of every N (N=%d) images to %s\n", varImageLogN->getInt(), logImage.getLogFileName());
    sendText(reply);
    snprintf(reply, MRL, "replay=true|false   replay (replay=%s) from %s\n", bool2str(isReplay()), getReplayFileName(r, MRL));
    sendText(reply);
    snprintf(reply, MRL, "step = N            replay N steps from replay file\n");
    sendText(reply);
    snprintf(reply, MRL, "logAcc=N            logging of every N (N=%d) acc value to %s \n", varAccLogN->getInt(), logAcc.getLogFileName());
    sendText(reply);
    sendText("help       This message\n");
    sendText("----\n");
    snprintf(reply, MRL, "see also: '%sPush' for event handling of 3d cloud\n", aliasName);
    sendText(reply);
    snprintf(reply, MRL, "see also: 'var %s' for parameters\n", aliasName);
    sendText(reply);
    sendHelpDone();
  }
  else
  { // get any command attributes (when not a help request)
    bool doLog = false;
    bool doOpen = false;
    bool aLog = msg->tag.getAttBool("log", &doLog, true);
    bool anOpen = msg->tag.getAttBool("open", &doOpen, true);
    bool silent = msg->tag.getAttBool("silent", NULL);
    bool aDebugValue = false;
    bool aDebug = msg->tag.getAttBool("debug", &aDebugValue, true);
    int aLogAccValue = 0;
    bool aLogAcc = msg->tag.getAttInteger("logAcc", &aLogAccValue, true);
    int aLogImageValue = 0;
    bool aLogImage = msg->tag.getAttInteger("logImage", &aLogImageValue, true);
    //
    // implement command options
    // replay
    bool valueBool;
    if (msg->tag.getAttBool("replay", &valueBool, true))
      setReplay(valueBool);
    // replay step
    int valueInt;
    if (msg->tag.getAttInteger("step", &valueInt, 1))
      replayStep(valueInt);
    //
    if (aLog)
    { // open or close the log
      logf.openLog(doLog);
      if (logf.isOpen())
        snprintf(reply, MRL, "Opened logfile %s", logf.getLogFileName());
      else if (doLog == false)
        snprintf(reply, MRL, "Closed logfile %s", logf.getLogFileName());
      else
        snprintf(reply, MRL, "Failed to open logfile %s", logf.getLogFileName());
      // send an information tag back to client
      if (not silent)
        sendInfo(reply);
    }
    if (aLogImage)
    { // open or close the image log
      varImageLogN->setValued(aLogImageValue);
      Wait(0.1);
      if (logImage.isOpen() and aLogImageValue > 0)
        snprintf(reply, MRL, "Image logfile is open: %s", logImage.getLogFileName());
      else if (aLogImageValue == 0)
        snprintf(reply, MRL, "Image logfile is closed: %s", logImage.getLogFileName());
      else if (aLogImageValue > 0)
        snprintf(reply, MRL, "Image logfile %s failed to open (is camera closed?)", logImage.getLogFileName());
      else
        snprintf(reply, MRL, "Image logfile %s failed to close", logImage.getLogFileName());
      // send an information tag back to client
      if (not silent)
        sendInfo(reply);
    }
    if (aLogAcc)
    { // open or close the acc log
      varAccLogN->setValued(aLogAccValue);
      Wait(0.1);
      if (logAcc.isOpen())
        snprintf(reply, MRL, "Acc logfile is open: %s", logAcc.getLogFileName());
      else
        snprintf(reply, MRL, "Acc logfile is closed: %s", logAcc.getLogFileName());
      // send an information tag back to client
      if (not silent)
        sendInfo(reply);
    }
    if (aDebug)
    {
      //varDebug->setValued(aDebugValue);
      if (varUseDepth8bit->getInt() == -1)
        varUseDepth8bit->setInt(1, 0, true);
      varUseDepth->setBool(true, 0, true);
      varUseDepthColor->setBool(true, 0, true);
      if (not silent)
      {
        snprintf(reply, MRL, "debug set to %s - (img=%d is color, img=%d is depth, img=%d is colored-depth img=%d is 8-bit BW image)", bool2str(aDebugValue),
                varImagesC3D->getInt(0), varImagesC3D->getInt(1), varImagesC3D->getInt(2), varImagesC3D->getInt(2));
        sendInfo(reply);
      }
    }
    if (anOpen)
    { // default update call
      varIsOpen->setBool(doOpen);
      if (not silent)
      {
        if (doOpen and varIsOpen->getBool())
          // OK result
          sendInfo("camera is requested to open");
        else if (not doOpen and not varIsOpen->getBool())
          sendInfo("camera is requested to close");
      }
    }
  }
  return true;
}

/////////////////////////////////////////////////////////////////

void UFuncKinect::createResources()
{
  // Create global variables - owned by this plug-in.
  varKinectNumber = addVar("kinectNumber", 0.0, "d", "(r/w) kinect number to be used on next open");
  varUpdateCnt = addVar("updCnt", 0.0, "d", "(r) Number of updates");
  //varPoseOnRobot = addVar("poseOnRobot", "0 0 0", "pose", "(rw) pose of left calera on robot");
  varFramerateDesired = addVar("desiredFramerate", 2.0, "d", "(rw) desired framerate (frames/sec) for both depth and color");
  varFramerate = addVar("measuredFramerate", "0 0", "d", "(r) [color, depth] measured framerate (frames/sec)");
  varResolution = addVar("desiredResolution", 1.0, "d", "(rw) desired resolution 0=low (QVGA), 1=medium (VGA), 2 = high)");
/*  varUseEveryCol = addVar("useEveryCol", 1.0, "d", "(r/w) use every Nth color/IR image received (0 is none)");
  varUseEveryDep = addVar("useEveryDepth", 1.0, "d", "(r/w) use every Nth depth image received (0 is none)");*/
  varImagesC3D = addVarA("imagesC3D", "18 19 20 21 22", "d", "(rw) Image pool for [0] color, [1] depth (16bit), [2] depth (RGB)image, [3] depth 8-bit BW, [4] corrected depth");
  varCamDeviceNum = addVarA("camDeviceNum", "18 19", "d", "(r/w) index to camera info - [color, depth]");
//  varDebug = addVar("debug", 1.0, "d", "(r/w) is images in imagepool to be maintained");
  varImgIR = addVar("imgIR", 0.0, "d", "(r/w) is IR (dot) image to replace color image [0=color, 1= IR]");
  varUseColor = addVar("useColor", "1 0", "d", "(rw) [0]=1 request color (at next open), [1]=1 is in use");
  varUseDepth = addVar("useDepth", "1 0", "d", "(rw) [0]=1 request depth (at next open), [1]=1 is in use");
  varUseCorrectedDepth = addVar("UseCorrectedDepth", "0", "d", "Set to one for correction the kinect depth. Depth image is then in mm.");
  varUseDepth8bit = addVar("useDepth8bit", 1.0, "d", "(rw) make 8-bit BW image from depth -1 = no image, 0-8 subtracts 512 and shift 0-8 bits");
  varUseDepthColor = addVar("useDepthColor", 0.0, "d", "(rw) make RGB pseudo color image from depth 0=do not make");
  varIsOpen = addVarA("open", "0 0", "d", "(rw) [0]: set to 0 to close set to 1 to open, [1]: 0:isclosed 1:isopen");
  varInitialized = addVar("initialized", 0.0, "d", "(r) is the camera initialized");
  varTiltDeg = addVar("tiltDeg", 0.0, "d", "(r/w) the current motor control tilt angle [degrees]");
  varTiltUse = addVar("tiltUse", 0.0, "d", "(r/w) should tilt control be attempted (0=not used, 1=used)");
  varLed = addVar("led", 1.0, "d", "(r/w) LED value: OFF 0, GREEN 1, RED 2, YELLOW 3, B-YELLOW 4, B-GREEN 5, B-RED_YELLOW = 6, B-RED_GREEN = 7");
//  varAccUse = addVar("useAcc", 0.0, "d", "(rw) Should acc sensor be read (after next open) 0=false (tilt disabled), 1=true");
  varAcc = addVarA("acc", "0 0 0", "3d", "(r) the current accelerometer reading in N/kg");
  varTime = addVar("time", 0.0, "t", "(r) Time at last update");
  varAccInterval = addVar("accInterval", 0.7, "d", "(r/w) wait getting acc-readings at least this time [sec]");
  varAccRate = addVar("accRate", 0.0, "d", "(r) rate of acc measurements (per second)");
  varAccLogN = addVar("accLogN", 0.0, "d", "(r/w) log acceleration evert N measurements (0 = close log)");
  varImageLogN = addVar("imageLogN", 0.0, "d", "(r/w) log images (color and depth) every Nth imageset (0 = close log)");
  varReplayLine = addVarA("replay", "0 0", "d", "(r) [0]: replay status 1=on, [1] current replay line");

  varMakePCLFile = addVarA("MakePCLFile", "0", "d", "set to save valid points in a PCL file");
  varMaxUsedDepth = addVarA("MaxUsedDepth", "10", "d", "The maximum accepted depth when working with PointCloudLib. Kinect datasheet notes 4.5 m as maximum valid distance.");
  //getting pointcloud
  addMethod("GetPointCloud", "dd",  "Get data in a pointcloud structure points (cloud type(0=xyz,1=xxyzrgb),max points(-1=no limit))");

  //
  { // set log file names
    const int MSL = 100;
    char s[MSL];
    logf.setLogName(getAliasName());
    snprintf(s, MSL, "%sImage", getAliasName());
    logImage.setLogName(s);
    replaySetBaseFileName(s);
    snprintf(s, MSL, "%sAcc", getAliasName());
    logAcc.setLogName(s);
  }
  // start read thread
  start();
}
//////////////////////////////////////////////////////
bool UFuncKinect::methodCall(const char * name, const char * paramOrder, char ** strings, const double * pars,
                      double * value, UDataBase ** returnStruct, int * returnStructCnt)
{
 bool result = true;
 if ((strcasecmp(name, "GetPointCloud") == 0) and (strcmp(paramOrder, "dd") == 0))
 {
   *returnStructCnt = GetXYZCoordinates((void *) returnStruct, pars[1],pars[0]);
   if (returnStructCnt != 0)
     *value = 1.0;
   else
     *value = 0.0;
 }
 else
   result = false;
 return result;
}

///////////////////////////////////////////

void UFuncKinect::callGotNewDataWithObject()
{
  UDataBase * data = &cloud3d;
  gotNewData(data);
}

#ifdef USE_KINECT

bool UFuncKinect::openKinect(bool doOpen)
{
  bool isOK;
  int err;
  frameLogCnt = 0;
  //
  // printf("UFuncKinect::openKinect entry\n");
  logf.toLog("Open/close call");
  if (varIsOpen->getBool(1) != doOpen)
  {
    bool doCloseDevice = not doOpen;
    // printf("UFuncKinect::openKinect trying to lock\n");
    logf.toLog("Open call - try lock");
    lock();
    if (doOpen)
    { // open the camera
      // printf("UFuncKinect::openKinect trying to open\n");
      logf.toLog("Try open");
      varIsOpen->setBool(0, 1);
      varUseColor->setBool(0, 1);
      varUseDepth->setBool(0, 1);
      if (not varInitialized->getBool())
      {
        err = libusb_init(&usbCtx);
        isOK = err == 0;
        if (isOK)
        {
          err = freenect_init(&f_ctx, usbCtx);
          isOK = err == 0;
        }
        if (isOK)
          // stop debug messages
          libusb_set_debug(usbCtx, 0);
        if (not isOK)
        {
          printf("freenect_init() failed (err = %d)\n", err);
          logf.toLog("freenect_init()", err, "failed - err number");
        }
        //printf("UFuncKinect::openKinect init done %s\n", bool2str(isOK));
        logf.toLog("freenect_init()", err, "is OK");
        varInitialized->setValued(isOK);
      }
      if (varInitialized->getBool())
      { // try open camera
        err = freenect_open_device(f_ctx, &f_dev, varKinectNumber->getInt());
        isOK = err == 0;
        if (not isOK)
        {
          printf("Could not open kinect device %d (err = %d)\n", varKinectNumber->getInt(), err);
          logf.toLog("freenect_open_device()", varKinectNumber->getInt(), err, "failed - err number");
        }
        varIsOpen->setBool(isOK, 1);
        //printf("UFuncKinect::openKinect open done %s\n", bool2str(isOK));
        logf.toLog("freenect_open_device()", varKinectNumber->getInt(), err, "is OK");
        //
        if (isOK)
        {
          int resi;
          freenect_resolution res = FREENECT_RESOLUTION_LOW;
          resi = varResolution->getInt();
          if (resi < 0 or resi > 2)
            varResolution->setInt(1);
          switch (varResolution->getInt())
          {
            case 2: res = FREENECT_RESOLUTION_HIGH; break;
            case 1: res = FREENECT_RESOLUTION_MEDIUM; break;
            default: res = FREENECT_RESOLUTION_LOW; break;
          }
          printf("UFuncKinect::openKinect setting callbacks %s\n", bool2str(isOK));
          logf.toLog("UFuncKinect::openKinect setting callbacks");
          //
          // depth mode and callback
          depthFmt = freenect_find_depth_mode(res, FREENECT_DEPTH_11BIT_PACKED);
          //fmt = freenect_get_depth_mode(1);
          freenect_set_depth_mode(f_dev, depthFmt);
          freenect_set_depth_callback(f_dev, depth_cb);
          //freenect_set_depth_format(f_dev, FREENECT_DEPTH_11BIT);
          //
          // set video format
          if (varImgIR->getBool())
          {
            videoFmt = freenect_find_video_mode(res, FREENECT_VIDEO_IR_8BIT);
            freenect_set_video_mode(f_dev, videoFmt);
            freenect_set_video_callback(f_dev, rgb_cb);
            //freenect_set_video_format(f_dev, FREENECT_VIDEO_IR_8BIT);
          }
          else
          {
            videoFmt = freenect_find_video_mode(res, FREENECT_VIDEO_BAYER);
            freenect_set_video_mode(f_dev, videoFmt);
            //freenect_set_video_format(f_dev, FREENECT_VIDEO_BAYER);
            freenect_set_video_callback(f_dev, rgb_cb);
          }
          printf("UFuncKinect::openKinect callbacks set %s\n", bool2str(isOK));
          logf.toLog("UFuncKinect::openKinect setting callbacks", err, "isOK");
          //
          err = 0;
          if (varUseDepth->getBool(0))
          {
            err = freenect_start_depth(f_dev);
            logf.toLog("UFuncKinect::openKinect depth started", err, "err number (0=OK)");
            printf("UFuncKinect::openKinect depth started err=%d number (0=OK)\n", err);
            varUseDepth->setBool(err == 0, 1, true);
            isOK = (err == 0);
            if (frameCntRgb > frameCntDepth)
              frameCntDepth = frameCntRgb;
            frameRateDepthTime.now();
          }
          if (varUseColor->getBool(0))
          {
            err = freenect_start_video(f_dev);
            logf.toLog("UFuncKinect::openKinect video started", err, "err number (0=OK)");
            printf("UFuncKinect::openKinect video started err=%d number (0=OK)\n", err);
            varUseColor->setBool(err == 0, 1, true);
            isOK &= (err == 0);
            if (frameCntDepth > frameCntRgb)
              frameCntRgb = frameCntDepth;
            frameRateRgbTime.now();
          }
          isOK = (err == 0);
          printf("UFuncKinect::openKinect started depth (%s) and camera (%s)\n",
                 bool2str(varUseDepth->getBool(1)), bool2str(varUseColor->getBool(1)));
          if (varTiltUse->getBool())
          {
            freenect_set_tilt_degs(f_dev,varTiltDeg->getInt());
            //varTiltUse->setBool(1, 1);
          }
          // set led to "recording"
          varLed->setValued(LED_RED);
          //freenect_set_led(f_dev,LED_RED);
          varIsOpen->setBool(err == 0, 1);
        }
      }
      else
        doCloseDevice = true;
    }
    if (doCloseDevice)
    { // close the camera
      //printf("UFuncKinect: shutting down streams...\n");
      logf.toLog("UFuncKinect::openKinect closing");
      varIsOpen->setBool(false, 1);
      // turn off LED
      freenect_set_led(f_dev, (freenect_led_options) 0);
      oldLed = 0;
      //
      freenect_stop_depth(f_dev);
      freenect_stop_video(f_dev);
      //
      freenect_close_device(f_dev);
      freenect_shutdown(f_ctx);
      varInitialized->setValued(false);
      varUseDepth->setBool(0, 1);
      varUseColor->setBool(0, 1);
      //varTiltUse->setBool(0, 1);
      logf.toLog("UFuncKinect::openKinect closed and shut");
    }
    unlock();
    //printf("UFuncKinect::openKinect finished\n");
  }
  return varIsOpen->getBool(1) == doOpen;
}

/////////////////////////////////////////////////////

void UFuncKinect::callback_depth(freenect_device *dev, uint16_t *depth, uint32_t timestamp)
{
  UTime t;
  t.now();
  // decode and use image
  UImagePool * imgPool = (UImagePool *)getStaticResource("imgPool", false, false);
  if (imgPool != NULL)
  { // raw depth image
    UImage * depthBW = imgPool->getImage(varImagesC3D->getInt(1), true);
    if (depthBW != NULL)
    {
      if (depthBW->tryLock())
      {
        depthBW->setSize(depthFmt.height, depthFmt.width, 1, 16, "BW16S");
        depthBW->setName("depth");
        // depth time is set, as the first usb-packet is arrived in the freenect driver
        depthBW->imgTime.SetTime(depthFrameTime);
        depthBW->imageNumber = frameCntDepth;
        depthBW->camDevice = varCamDeviceNum->getInt(1);
        depthBW->used = false;
        // convert from raw data to 16-bit BW image
        // convert_packed11_to_16bit(uint8_t *sec, uint16_t *dst, int n)
        convert_packed11_to_16bit((uint8_t *) depth, (uint16_t*)depthBW->getData(), 640*480);
        //memmove(depthBW->getData(), depth, depthFmt.bytes);
        logDepthImage = depthBW;
        depthBW->updated();
        // there may be need for processed depth images (to get fake color and 8-bit BW)
        processDepthImages(depthBW);
        // release
        depthBW->unlock();
      }
    }
  }
  //
  varUpdateCnt->add(1.0);  varUpdateCnt->add(1.0);
  frameCntDepth++;
  const int FRAMERATE_IMGS = 10;
  if (frameCntDepth % FRAMERATE_IMGS == 0)
  {
    //int dti = timestamp - frameRateVStamp;
    //frameRateVStamp = timestamp;
    double d = frameRateDepthTime.getTimePassed();
    // debug
    //printf("%d frames took %.3f sec and %d kinect timestamp units (now %u)\n", FRAMERATE_IMGS, d, dti, timestamp);
    // debug
    if (d > 1e-6)
    { // time has passed
      varFramerate->setValued(roundi(FRAMERATE_IMGS / d * 100.0)/100.0, 1, true);
      frameRateDepthTime.now();
    }
  }
}

///////////////////////////////////////////////////////////////////////////

void UFuncKinect::callback_rgb(freenect_device *dev, uint8_t *rgb, uint32_t timestamp)
{
  UTime t;
  t.Now();
  // use the image
  UImagePool * imgPool = (UImagePool *)getStaticResource("imgPool", false, false);
  UImage * rgbImg = NULL;
  //
  if (imgPool != NULL)
    rgbImg = imgPool->getImage(varImagesC3D->getInt(0), true, videoFmt.height, videoFmt.width, 3, 8);
  if (rgbImg != NULL)
  {
    if (rgbImg->tryLock())
    {
      rgbImg->imageNumber = frameCntRgb;
      // video frame time is set, as the first usb-packet is arrived in the freenect driver
      rgbImg->imgTime.SetTime(videoFrameTime);
      unsigned char * pix = rgbImg->getUCharRef(0, 0);
      if (varImgIR->getBool())
      { // IR image
        if (rgbImg->getChannels() != 1)
          rgbImg->setSize(videoFmt.height, videoFmt.width, 1, 8);
        rgbImg->setColorType("BW");
        memcpy(pix, rgb, videoFmt.bytes);
        rgbImg->setName("kinect IR");
      }
      else
      { // color image (GRBG)
        // changed colot type to BAYER
        if (rgbImg->getChannels() != 1)
          rgbImg->setSize(videoFmt.height, videoFmt.width, 1, 8);
        rgbImg->setColorType("GRBG");
        memcpy(pix, rgb, videoFmt.bytes);
        rgbImg->setName("kinect GRBG");
      }
      rgbImg->camDevice = varCamDeviceNum->getInt(0);
      logVideoImage = rgbImg;
      rgbImg->updated();
      rgbImg->unlock();
    }
  }
  varUpdateCnt->add(1.0);
  frameCntRgb++;
  const int FRAMERATE_IMGS = 10;
  if (frameCntRgb % FRAMERATE_IMGS == 0)
  {
    //int dti = timestamp - frameRateVStamp;
    //frameRateVStamp = timestamp;
    double d = frameRateRgbTime.getTimePassed();
    // debug
    //printf("%d frames took %.3f sec and %d kinect timestamp units (now %u)\n", FRAMERATE_IMGS, d, dti, timestamp);
    // debug
    if (d > 1e-6)
    { // time has passed
      varFramerate->setValued(roundi(FRAMERATE_IMGS / d * 100.0)/100.0, 0);
      frameRateRgbTime.now();
    }
  }
}

#endif

///////////////////////////////////////////////////

void * startUFuncKinectThread(void * obj)
{ // call the hadling function in provided object
  UFuncKinect * ce = (UFuncKinect *)obj;
  ce->run();
  pthread_exit((void*)NULL);
  return NULL;
}

///////////////////////////////////////////////////

bool UFuncKinect::start()
{
  int err = 0;
  pthread_attr_t  thAttr;
  //
  if (not threadRunning)
  {
    pthread_attr_init(&thAttr);
    //
    threadStop = false;
    // create socket server thread
    err = (pthread_create(&threadHandle, &thAttr,
              &startUFuncKinectThread, (void *)this) == 0);
    pthread_attr_destroy(&thAttr);
  }
  return err;
}

///////////////////////////////////////////////////

void UFuncKinect::stop(bool andWait)
{
  if (threadRunning and not threadStop)
  { // stop and join thread
    threadStop = true;
    pthread_join(threadHandle, NULL);
  }
}

/////////////////////////////////////////////////////


void UFuncKinect::run()
{
  int err = 0;
  int errCnt = 0, accCnt = 0;
  UPosition acc;
  int16_t accOld[3] = {0,0,0};
  UTime t, t2, tFr;
  int frameRateLow = 0;
  if (threadRunning)
    // prevent nested calls;
    return;
  threadRunning = true;
  t.now();
  tFr.Now();
  bool timeToLogColor = false;
  int lastImageNumber = 0, lastDepthNumber = 0;
  while (not threadStop)
  {
    if (varIsOpen->getBool(1))
    {
      lock();
#ifdef USE_KINECT
      if (true) //varAccUse->getBool(0))
      {
        freenect_raw_tilt_state* state = NULL;
        int useEvery;
        if (varResolution->getInt() == 1)
          useEvery = maxi(1, roundi(30.0 / varFramerateDesired->getInt()));
        else
          useEvery = maxi(1, roundi(10.0 / varFramerateDesired->getInt()));
        //
        if (useEvery > 2)
          syncVideoFromDepth = varUseDepth->getBool();
        else
          syncVideoFromDepth = 0;
        if (useEvery != useDepthFrame or syncVideoFromDepth < 0)
        { // always let depth control video frame rate, to get matched pairs
          if (useEvery < useDepthFrame)
            // going faster, ensure next available frame is used
            useDepthCnt = useEvery;
          useDepthFrame = useEvery;
          useVideoFrame = useEvery + 2; // large value, should be triggered by depth
          printf("aukinect::run: Using every %d set of images\n", useEvery);
        }
        double dt = t.getTimePassed();
        double ai = varAccInterval->getValued();
        if (dt > ai or ((depthIdle == 1 and videoIdle == 1 and dt > ai/2.0)))
        { // prefer to get acc values in image idle time
          freenect_update_tilt_state(f_dev);
          state = freenect_get_tilt_state(f_dev);
          if (state->accelerometer_x != accOld[0] or
              state->accelerometer_y != accOld[1] or
              state->accelerometer_z != accOld[2])
          { // new acc measurement
            accOld[0] = state->accelerometer_x;
            accOld[1] = state->accelerometer_y;
            accOld[2] = state->accelerometer_z;
            freenect_get_mks_accel(state, &acc.x, &acc.y, &acc.z);
            varAcc->set3D(&acc);
            accCnt++;
            t.Now();
            varTime->setTime(t);
            if (logAcc.isOpen() and (accCnt % varAccLogN->getInt() == 0))
            { // log acc value
              fprintf(logAcc.getF(), "%lu.%06lu %.4f %.4f %.4f\n", t.GetSec(), t.GetMicrosec(), acc.x, acc.y, acc.z);
            }
            if (accCnt >= 20)
            {
              dt = t - t2;
              t2 = t;
              varAccRate->setValued(roundi(accCnt/dt*100.0)/100.0);
              accCnt = 0;
            }
          }
        }
        // test new tilt command
        if (oldTilt != varTiltDeg->getDouble() and varTiltUse->getBool())
        { // new desired tilt value
          const int MSL = 50;
          char s[MSL];
          //
          if (state != NULL)
          {
            oldTilt = varTiltDeg->getDouble();
            freenect_set_tilt_degs(f_dev, oldTilt);
            snprintf(s, MSL, "tilt %6.2f deg set value (measured %g deg)", varTiltDeg->getDouble(), freenect_get_tilt_degs(state));
            logf.toLog(s);
            logImage.toLog(s);
          }
        }
      }
      // test new LED command
      if (oldLed != varLed->getInt())
      {
        freenect_set_led(f_dev, (freenect_led_options) varLed->getInt());
        oldLed = varLed->getInt();
        logf.toLog("set LED to ", oldLed, "(0..7: off,green,red,yellow,blink-Y,blink-G,blink-RY)");
      }
      err = freenect_process_events(f_ctx);
      if (err < 0)
        errCnt++;
#endif
      unlock();
#ifdef USE_KINECT
      if (tFr.getTimePassed() * varFramerateDesired->getDouble() > 15.0)
      { // more than 15 framintervals has passed, so test result
        if (varFramerate->getDouble() < varFramerateDesired->getDouble() * 0.4 and varIsOpen->getBool())
          frameRateLow++;
        else
          frameRateLow = 0;
        if (frameRateLow > 3)
        { // close and reopen the camera
          const int MSL = 200;
          char ms[MSL];
          openKinect(false);
          snprintf(ms, MSL, "KINECT::run(): closed device, too low framerate %.2f, desired=%.2f", varFramerate->getDouble(), varFramerateDesired->getDouble());
          logf.toLog(ms);
          printf("%s\n", ms);
          Wait(0.5);
          openKinect(true);
          snprintf(ms, MSL, "KINECT::run(): reopened device");
          logf.toLog(ms);
          printf("%s\n", ms);
          frameRateLow = 0;
        }
        tFr.Now();
      }
      if (not varIsOpen->getBool(0))
        // close kinect requested
        openKinect(false);
#endif
    }
    else
    { // update interval times when camera is closed
      if (varIsOpen->getBool(0))
        // requested to open kinect
        openKinect(true);
      Wait(0.05);
      t.now();
      tFr.now();
    }
    // test for open/close of logfiles - image log
    logFileTest();
    // should images be logged
    if (logImage.isLogOpen())
    {
      int logn = varImageLogN->getInt();
      if (logDepthImage != NULL)
      { // is may be time to log depth image
        if ((int)logDepthImage->imageNumber - lastDepthNumber >= logn)
        {
          lastDepthNumber = logDepthImage->imageNumber;
          // save image and make an entry in image log
          logImageToFile(logDepthImage);
          //  printf("Logged depth image %d\n", frameLogCnt);
          timeToLogColor = true;
        }
      }
      // is it time to log color image
      if (logVideoImage != NULL)
      { // save image and make an entry in image log
        if (timeToLogColor and logn > 1)
          // force logging of color - triggered by depth
          lastImageNumber = 0;
        if ((int)logVideoImage->imageNumber - lastImageNumber >= logn)
        {
          lastImageNumber = logVideoImage->imageNumber;
          logImageToFile(logVideoImage);
          //printf("Logged video image %d\n", frameLogCnt);
          timeToLogColor = false;
        }
      }
    }
    //
    if (errCnt > 10)
    {
      printf("UFuncKinect::run: %d freenect_process_events errors (lase err=%d) - closing device\n", errCnt, err);
      errCnt = 0;
    }
  }
  threadRunning = false;
}

/////////////////////////////////////////////////////////

void UFuncKinect::logFileTest()
{
  if (logImage.isOpen() and varImageLogN->getInt() == 0)
  {
    logImage.openLog(false);
    logf.toLog("closed imagelog");
  }
  else if (not logImage.isOpen() and varImageLogN->getInt() > 0)
  {
    if (not logImage.openLog(true))
    { // error opening logfile
      printf("******** failed to open %s (setting imageLogN=0)\n", logImage.getLogFileName());
      logf.toLog("failed to open ", logImage.getLogFileName());
      varImageLogN->setValued(0.0);
    }
    else
      logf.toLog("opened imagelog", logImage.getLogFileName());
  }
  // test for logfiles - acc log
  if (logAcc.isOpen() and varAccLogN->getInt() == 0)
    logAcc.openLog(false);
  else if (not logAcc.isOpen() and varAccLogN->getInt() > 0)
  {
    if (not logAcc.openLog(true))
    { // error opening logfile
      printf("******** failed to open %s (setting accLogN=0)\n", logAcc.getLogFileName());
      logf.toLog("failed to open ", logAcc.getLogFileName());
      varAccLogN->setValued(0.0);
    }
    else
      logf.toLog("opened acc log", logAcc.getLogFileName());
  }
}

/////////////////////////////////////////////////////////////

bool UFuncKinect::logImageToFile(UImage * imgToLog)
{
  bool result = false;
  if (varImageLogN->getInt() > 0)
  {
    UCamPool * cams = (UCamPool * ) getStaticResource("campool", false, false);
    if (cams != NULL)
    { // we have a camera
      UCamMounted * cam = cams->getCam(imgToLog->camDevice);
      if (cam == NULL)
      {
        const int MCSL = 20;
        char cs[MCSL];
        snprintf(cs, MCSL, "kinectDev%d", imgToLog->camDevice);
        cams->makeDevice(imgToLog->camDevice, cs);
        cam = cams->getCam(imgToLog->camDevice);
      }
      if (cam != NULL)
      {
        imgToLog->lock();
        logImage.logImage(imgToLog, cam);
        imgToLog->unlock();
        result = true;
      }
    }
  }
  return result;
}

////////////////////////////////////////

bool UFuncKinect::decodeReplayLine(char* line)
{
  varReplayLine->add(1.0, 1);
//   1310653790.415352 36 480 640 1050.00 19 0.000 0.000 0.000 0.0000 0.0000 0.0000 BW16S00000036-cam19-20110714_162950.415.png
//   1310653790.437549 36 480 640 1050.00 18 0.000 0.000 0.000 0.0000 0.0000 0.0000 GRBG00000036-cam18-20110714_162950.437.png
//   1310653793.619357 42 480 640 1050.00 19 0.000 0.000 0.000 0.0000 0.0000 0.0000 BW16S00000042-cam19-20110714_162953.619.png
//   1310653793.637544 42 480 640 1050.00 18 0.000 0.000 0.000 0.0000 0.0000 0.0000 GRBG00000042-cam18-20110714_162953.637.png
  int imgSerial;
  int camDevNum;
  char * p1 = line;
  int state = 0;
  UTime t;
  char * filename = NULL;
  UImagePool * iPool;
  UImage * img;
  while (*p1 >= ' ' and state <= 12)
  {
    switch (state)
    {
      case 0:
        t.setTimeTod(p1);
        p1 = strchr(line, ' ');
        break;
      case 1: // image serial
        imgSerial = strtol(p1, &p1, 10); break;
      case 5: // camera device number
        camDevNum = strtol(p1, &p1, 10); break;
      case 12:
        while (isspace(*p1))
          p1++;
        if (*p1 > ' ')
        {
          filename = p1;
          // remove white space and linefeed at end
          p1 = &filename[strlen(filename) - 1];
          while (*p1 <= ' ')
            *p1-- = '\0';
        }
        break;
      default: // unused numbers
        strtof(p1, &p1);
        break;
    }
    state++;
  }
  if (filename != NULL)
  {
    iPool = (UImagePool *) getStaticResource("imgPool", false, true);
    if (iPool != NULL)
    {
      const int MFL = 500;
      char ffname[MFL];
      bool isOK;
      //
      img = iPool->getImage(camDevNum, true);
      isOK = img != NULL;
      if (isOK)
      {
        img->lock();
        snprintf(ffname, MFL, "%s/%s", replayPath, filename);
        isOK = img->loadPNG(ffname);
      }
      if (isOK)
      {
        img->imageNumber = imgSerial;
        img->imgTime = t;
        img->camDevice = camDevNum;
        img->setName(filename);
        img->updated();
        if (camDevNum == varImagesC3D->getInt(1))
          // this is a depth image - may need extra processing
          processDepthImages(img);
      }
      if (img != NULL)
        img->unlock();
    }
  }
  return true;
}

/////////////////////////////////////////

void UFuncKinect::updateReplayStatus()
{
  varReplayLine->setBool(isReplay(), 0);
}

////////////////////////////////////////
bool UFuncKinect::processDepthImages(UImage * img)
{
  UImagePool * iPool;
  //
  int lims = (int)(varMaxUsedDepth->getDouble(0)*1000);
  if (varUseCorrectedDepth->getBool() or varUseDepthColor->getBool() or varUseDepth8bit->getInt() >= 0)
  { // make depth image in fake colors
    iPool = (UImagePool *) getStaticResource("imgPool", false, true);
    if (iPool != NULL)
    {
      int h = img->getHeight();
      int w = img->getWidth();
// make corrected depth image and update 
      UImage * cDepthImg = iPool->getImage(varImagesC3D->getInt(4), true, h, w);
      if (cDepthImg != NULL and varUseCorrectedDepth->getBool())
      {
        if (cDepthImg->tryLock())
        {
          cDepthImg->copyMeta(img, false);
          cDepthImg->setSize(h, w, 1, 16, "BW16S");
          cDepthImg->setName("Corrected depth [mm]");
          cDepthImg->used = false;
          uint16_t * pix = (uint16_t *) cDepthImg->getData();
          uint16_t * src = (uint16_t *) img->getData();
          for (int i = 0; i < h * w; i++)
          { // corret the 
// values found at http://stackoverflow.com/questions/8663301/microsoft-kinect-sdk-depth-calibration
            *pix = t_depth[*src];
if(*pix > lims) *pix = 0;
            src++; pix++;
          }
          cDepthImg->updated();
          cDepthImg->unlock();
          pix = (uint16_t *) cDepthImg->getData();
          src = (uint16_t *) img->getData();
          //printf("[%d],[%d]\n",pix[h/2*w+w/2],src[h/2*w+w/2]);
//if depth image is successfull check if PCL file is requested
          if (varMakePCLFile->getBool())
            UFuncKinect::MakePCLFile(cDepthImg);
        }
      }

// make color depth image
      UImage * depthImg = iPool->getImage(varImagesC3D->getInt(2), true, h, w);
      if (depthImg != NULL and varUseDepthColor->getBool())
      {
        if (depthImg->tryLock())
        {
          depthImg->copyMeta(img, false);
          depthImg->setColorType(PIX_PLANES_RGB);
          depthImg->setName("kinect RGB depth");
          UPixel * pix = depthImg->getData();
          uint16_t * src = (uint16_t *) img->getData();
          for (int i = 0; i < h * w; i++)
          { // get a good gamma value and convert to color
            int pval = t_gamma[*src];
            int lb = pval & 0xff;
            switch (pval>>8) {
              case 0: pix->set(     255, 255-lb, 255-lb);  break;
              case 1: pix->set(     255,     lb,      0);  break;
              case 2: pix->set(255 - lb,    255,      0);  break;
              case 3: pix->set(       0,    255,     lb);  break;
              case 4: pix->set(       0, 255-lb,    255);  break;
              case 5: pix->set(       0,      0, 255-lb);  break;
              default:pix->set(       0,      0,      0);  break;
            }
            src++;
            pix++;
          }
          depthImg->updated();
          depthImg->unlock();
        }
      }
// make an 8-bit BW image of depth, used corrected debth is possible, "varUseDepth8bit" should be updated then
      int bw8bit = varUseDepth8bit->getInt();
      if (bw8bit >= 0)
      { // make an 8-bit BW image of depth
        UImage * depthBW2 = iPool->getImage(varImagesC3D->getInt(3), true);
        if (depthBW2 != NULL)
        {
          if (depthBW2->tryLock())
          {
            depthBW2->copyMeta(img, false);
            depthBW2->setSize(h, w, 1, 8, "BW");
            depthBW2->setName("depth-8bit");
            depthBW2->used = false;
            uint16_t * ps;
            if(varUseCorrectedDepth->getBool())
            {
              if (cDepthImg->tryLock())
                ps = (uint16_t *) cDepthImg->getData();
              else
                ps = (uint16_t *) img->getData();
            }
            else
              ps = (uint16_t *) img->getData();
            unsigned char * pd = depthBW2->getUCharRef(0, 0);
            for (int p = 0; p < h * w; p++)
              *pd++ = mini(((*ps++ - 512) >> bw8bit) , 0xff);
            depthBW2->updated();
            depthBW2->unlock();
            if(varUseCorrectedDepth->getBool())
              cDepthImg->unlock();
          }
        }
      }
    }
  }
  return true;
}
//////////////////////////////////////////////////////////////////////
int UFuncKinect::MakePCLFile(UImage * img) //makes a single PCL file
{
  char FileName[100];
  int i,x,y;
  long NumEl;
  int h = img->getHeight();
  int w = img->getWidth();
  uint16_t * src = (uint16_t *) img->getData();
  // make file
  FILE* PCLFile;
  i = sprintf(FileName,"KinPCL%ld.pcd",img->imageNumber);
  FileName[i] = 0;
  printf("%s\n",FileName);
  PCLFile = fopen(FileName,"w");
  printf("writing to file(%ld)\n",(long)PCLFile);
  int lims = (int)(varMaxUsedDepth->getDouble(0)*1000);
  if(PCLFile != NULL)
  {
    //count number for valid elements
    NumEl = 0;
    for (y=0;y<h;y++)
      for (x=0;x<w;x++)
      {
        if((*src > 0) && (*src < lims))
          NumEl++;
        src++;
      }

//file format found at http://pointclouds.org/documentation/tutorials/pcd_file_format.php#pcd-file-format
/*
# .PCD v.7 - Point Cloud Data file format
VERSION .7
FIELDS x y z rgb
SIZE 4 4 4 4
TYPE F F F F
COUNT 1 1 1 1
WIDTH 213
HEIGHT 1
VIEWPOINT 0 0 0 1 0 0 0
POINTS 213
DATA ascii
0.93773 0.33763 0 4.2108e+06
...
*/
   fprintf(PCLFile,"# .PCD v.7 - Point Cloud Data file format\n");
   fprintf(PCLFile,"VERSION .7\n");
   fprintf(PCLFile,"FIELDS x y z\n");
   fprintf(PCLFile,"SIZE 4 4 4\n");
   fprintf(PCLFile,"TYPE F F F\n");
   fprintf(PCLFile,"COUNT 1 1 1\n");
   fprintf(PCLFile,"WIDTH %ld\n",NumEl);
   fprintf(PCLFile,"HEIGHT %d\n",1);
   fprintf(PCLFile,"VIEWPOINT 0 0 0 1 0 0 0\n");
   fprintf(PCLFile,"POINTS %ld\n",NumEl);
   fprintf(PCLFile,"DATA ascii\n");
// white all data points
   src = (uint16_t *) img->getData();
    for (y=0;y<h;y++)
      for (x=0;x<w;x++)
      {
        if(*src > 0)
          fprintf(PCLFile,"%f %f %f\n",(float)(*src) * t_posX[x]/1000,(float)(*src) * t_posY[y]/1000,(float)*src/1000);
        src++;
      }
   fclose(PCLFile);
    printf("writing done\n");
  }
  
  varMakePCLFile->setInt(0, 0, true); //clear make file flag
  if(PCLFile != NULL)
    return 1;
  else
    return 0;
}
////////////////////////////////////////////////////////////////////////

int UFuncKinect::GetXYZCoordinates(void *pointCloud, int Max,int type)
// returns all valid points as a long list of XYZ 
// 4 options:
// 1: XYZ & corrected depth ok
// 2: XYZ & corrected depth not ok
// 1: XYZRGB & corrected depth ok
// 2: XYZRGB & corrected depth not ok
{
  
  int k = 0; // pointcloud index
  int y = 0; // Y counter
  int x = 0; // X counter
  int dLims = (int)(varMaxUsedDepth->getDouble(0)*1000);
  if (Max == -1) Max = 640*480;
  printf("distance limit:%d\n",dLims);
  UImagePool * iPool;
  iPool = (UImagePool *) getStaticResource("imgPool", false, true);
  if (iPool != NULL)
  {
    if(type == 0) // if XYZ cloud
    {
//   pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_o (new pcl::PointCloud<pcl::PointXYZ>); 
   pcl::PointCloud<pcl::PointXYZ>::Ptr *cloud;// = &cloud_o; 

 //     pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (reinterpret_cast<pcl::PointCloud<pcl::PointXYZ> *>(pointCloud)); // make a cloud that is pointing to the link
      cloud = reinterpret_cast<pcl::PointCloud<pcl::PointXYZ>::Ptr *>(pointCloud);
      if(varUseCorrectedDepth->getBool())
      {
        UImage * cDepthImg = iPool->getImage(varImagesC3D->getInt(4), true, 480, 640);
        if (cDepthImg != NULL)
        {
          if (cDepthImg->tryLock())
          {
            int h = cDepthImg->getHeight();
            int w = cDepthImg->getWidth();
            (*cloud)->width  = h*w;
            (*cloud)->height = 1;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
            uint16_t * pix = (uint16_t *) cDepthImg->getData();
            //run through all pixels
            for(y = 0;y < h;y++)
              for(x = 0;x < w && k < Max;x++)
              {
                 // if the pixel value is valid
                 if((*pix > 0) && (*pix < dLims))
                 {
                   (*cloud)->points[k].x = ((float)(*pix))/1000 * t_posX[x];
                   (*cloud)->points[k].y = ((float)(*pix))/1000 * t_posY[y];
                   (*cloud)->points[k].z = ((float)(*pix))/1000;
                   k ++;
                 }
                 pix++;
              }
            cDepthImg->unlock();
            (*cloud)->width  = k;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
          }// if try lock
        }// if cdept!=0
      }//if corrected depth
      else
      {
        UImage * depthImg = iPool->getImage(varImagesC3D->getInt(1), true, 480, 640);
        if (depthImg != NULL)
        {
          if (depthImg->tryLock())
          {
            int h = depthImg->getHeight();
            int w = depthImg->getWidth();
            int P;
            (*cloud)->width  = h*w;
            (*cloud)->height = 1;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
            uint16_t * pix = (uint16_t *) depthImg->getData();
            //run through all pixels
            for(y = 0;y < h;y++)
              for(x = 0;x < w;x++)
              {
                 P = t_depth[*pix];
                 // if the pixel value is valid
                 if(P > 0 && P < dLims)
                 {
                   (*cloud)->points[k].x = ((float)(P))/1000 * t_posX[x];
                   (*cloud)->points[k].y = ((float)(P))/1000 * t_posY[y];
                   (*cloud)->points[k].z = ((float)(P))/1000;
                   k ++;
                 }
                 pix++;
              }
            depthImg->unlock();
            (*cloud)->width  = k;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
          }// if try locvk
        }// if =0
      }// if not corrected depth 
    }
    if(type == 1) // if XYZrgb cloud
    {
      pcl::PointCloud<pcl::PointXYZRGB>::Ptr *cloud;// = &cloud_o; 
      cloud = reinterpret_cast<pcl::PointCloud<pcl::PointXYZRGB>::Ptr *>(pointCloud);
      if(varUseCorrectedDepth->getBool())
      {
        UImage * cDepthImg = iPool->getImage(varImagesC3D->getInt(4), true, 480, 640);
        UImage * RGBImg = iPool->getImage(varImagesC3D->getInt(0), true, 480, 640);
        if (cDepthImg != NULL)
        {
          if (cDepthImg->tryLock())
          {
            int h = cDepthImg->getHeight();
            int w = cDepthImg->getWidth();
            (*cloud)->width  = h*w;
            (*cloud)->height = 1;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
            uint16_t * pix = (uint16_t *) cDepthImg->getData();
            UPixel * cpix = RGBImg->getData();
            //run through all pixels
            for(y = 0;y < h;y++)
              for(x = 0;x < w && k < Max;x++)
              {
                 // if the pixel value is valid
                 if((*pix > 0) && (*pix < dLims))
                 {
                   (*cloud)->points[k].x = ((float)(*pix))/1000 * t_posX[x];
                   (*cloud)->points[k].y = ((float)(*pix))/1000 * t_posY[y];
                   (*cloud)->points[k].z = ((float)(*pix))/1000;
                   (*cloud)->points[k].r = cpix->p1;
                   (*cloud)->points[k].g = cpix->p2;
                   (*cloud)->points[k].b = cpix->p3;
                   k ++;
                 }
                 pix++;cpix++;
              }
            cDepthImg->unlock();
            (*cloud)->width  = k;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
          }// if try lock
        }// if cdept!=0
      }//if corrected depth
      else
      {
        UImage * depthImg = iPool->getImage(varImagesC3D->getInt(1), true, 480, 640);
        UImage * RGBImg = iPool->getImage(varImagesC3D->getInt(0), true, 480, 640);
        if (depthImg != NULL)
        {
          if (depthImg->tryLock())
          {
            int h = depthImg->getHeight();
            int w = depthImg->getWidth();
            int P;
            (*cloud)->width  = h*w;
            (*cloud)->height = 1;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
            uint16_t * pix = (uint16_t *) depthImg->getData();
            UPixel * cpix = RGBImg->getData();
            //run through all pixels
            for(y = 0;y < h;y++)
              for(x = 0;x < w;x++)
              {
                 P = t_depth[*pix];
                 // if the pixel value is valid
                 if(P > 0 && P < dLims)
                 {
                   (*cloud)->points[k].x = ((float)(P))/1000 * t_posX[x];
                   (*cloud)->points[k].y = ((float)(P))/1000 * t_posY[y];
                   (*cloud)->points[k].z = ((float)(P))/1000;
                   (*cloud)->points[k].r = cpix->p1;
                   (*cloud)->points[k].g = cpix->p2;
                   (*cloud)->points[k].b = cpix->p3;
                   k ++;
                 }
                 pix++;
              }
            depthImg->unlock();
            (*cloud)->width  = k;
            (*cloud)->points.resize ((*cloud)->width * (*cloud)->height);
          }// if try locvk
        }// if =0
      }// if not corrected depth 
    }
    else
    {
      //return error;
    }
  }// if ipool

  return k;
}

